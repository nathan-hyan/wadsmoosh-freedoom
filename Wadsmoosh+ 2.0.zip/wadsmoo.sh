#!/bin/sh
python wadsmoosh.py "$1"

